package playground;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface GroundRepository extends PagingAndSortingRepository<Ground, Long>{


}